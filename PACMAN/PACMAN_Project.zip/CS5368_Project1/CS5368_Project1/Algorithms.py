import util

class DFS(object):
    def depthFirstSearch(self, problem):
        """
        Search the deepest nodes in the search tree first
        [2nd Edition: p 75, 3rd Edition: p 87]

        Your search algorithm needs to return a list of actions that reaches
        the goal.  Make sure to implement a graph search algorithm
        [2nd Edition: Fig. 3.18, 3rd Edition: Fig 3.7].

        To get started, you might want to try some of these simple commands to
        understand the search problem that is being passed in:

        print "Start:", problem.getStartState()
        print "Is the start a goal?", problem.isGoalState(problem.getStartState())
        print "Start's successors:", problem.getSuccessors(problem.getStartState())
        """
        "*** TTU CS5368 YOUR CODE HERE ***"
        startingNode = problem.getStartState()
        if problem.isGoalState(startingNode):
            return []

        stack = util.Stack()
        visited = []
        stack.push((startingNode, []))
        action1 = []
        ind = False

        def DFSUtil(stack, problem, visited):
            nonlocal action1, ind
            Node, actions = stack.pop()
            if problem.isGoalState(Node) and not ind:
                action1 = actions
                ind = True
                return
            if Node not in visited and not ind:
                visited.append(Node)
                list1 = problem.getSuccessors(Node)
                list1 = list1[::-1]
                for nextNode, action, cost in list1:
                    if nextNode not in visited:
                        stack.push((nextNode, actions + [action]))
                        DFSUtil(stack, problem, visited)

        DFSUtil(stack, problem, visited)
        return action1


class BFS(object):
    def breadthFirstSearch(self, problem):
        "*** TTU CS5368 YOUR CODE HERE ***"
        startingNode = problem.getStartState()
        if problem.isGoalState(startingNode):
            return []

        myQueue = util.Queue()
        visited = []
        myQueue.push((startingNode, []))
        action1 = []
        ind = False

        def BFSUtil(myQueue, problem):
            nonlocal action1, ind, visited
            Node, actions = myQueue.pop()
            if problem.isGoalState(Node) and not ind:
                action1 = actions
                ind = True
                return
            if Node not in visited:
                visited.append(Node)
            list1 = problem.getSuccessors(Node)
            skip = False
            for nextNode, action, cost in list1:
                if nextNode not in visited:
                    for i in myQueue.list:
                        if i[0] == nextNode:
                            if len(i[1]) > len([action]+actions):
                                myQueue.list.remove(i)
                            else:
                                skip = True
                    if not skip:
                        myQueue.push((nextNode, actions + [action]))
                    skip = False
            BFSUtil(myQueue, problem)

        BFSUtil(myQueue, problem)
        return action1


class UCS(object):
    def uniformCostSearch(self, problem):
        "*** TTU CS5368 YOUR CODE HERE ***"
        startLocation = problem.getStartState()
        if problem.isGoalState(startLocation):
            return []
        # This can also be implemented using recursion but python has a recursion limit of 1000 in our case we have
        # problems with 16000 nodes which cannot be achieved with recursion so sticking with iterative approach
        visited = []
        priorityQueue = util.PriorityQueue()
        priorityQueue.push((startLocation, [], 0), 0)

        while priorityQueue:
            Node, action, prev = priorityQueue.pop()
            if Node not in visited:
                visited.append(Node)
                if problem.isGoalState(Node):
                    return action
                for nextNode, action_1, cost in problem.getSuccessors(Node):
                    priorityQueue.push((nextNode, action + [action_1], prev + cost), prev + cost)


class aSearch (object):

    def nullHeuristic( state, problem=None):
        """
        A heuristic function estimates the cost from the current state to the nearest goal in the provided SearchProblem.  This heuristic is trivial.
        """
        return 0
    def aStarSearch(self,problem, heuristic=nullHeuristic):
       # Assigning  the priority Queue data type from util
        pState = util.PriorityQueue()
        vStates = []  # Initializing the visitedStates variable with empty list
        sState = problem.getStartState()  # Assigning  the start state to a variable
        pState.push((0, [], sState), 0)  # Pushing the Initial state item with zero cost to priority queue

        while not pState.isEmpty():  # checking  while the possible state is not Empty

            cost, actions, cVState = pState.pop()  # we will get the state item with least cost from  priority queue

            vStates.append((cost, cVState))  # Append visited states with cost and current state
            # visitedStates[currentVisitedState] = cost

            if problem.isGoalState(cVState):  # validating  if the current state is Goal to return actions
                return actions

            else:
                nextStates = problem.getSuccessors(
                    cVState)  # If Goal is not reached, Get the successors/child states

                for nextState, nextAction, nextCost in nextStates:  # Iterate through next states

                    cumActions = actions + [nextAction]
                    cumCost = problem.getCostOfActions(cumActions)  # Get cummulative actions and cost
                    # cummulativeCost = cost + nextCost
                    prev_visited = False

                    for visited in vStates:  # Gothrough all visited states to validate if current state ...
                        visitedCost, visitedState = visited  # ... is already visited and cummulative cost is greater.

                        if ((nextState == visitedState) and
                                (cumCost >= visitedCost)):
                            prev_visited = True

                    if not prev_visited:  # If current state is not visited then update successor/child state items ...
                        pState.push(
                            # ... with cummulative cost and priority to queue as cummulative cost with heuristic cost.
                            (cumCost, cumActions, nextState),
                            cumCost + heuristic(nextState, problem))
                        vStates.append((cumCost, nextState))
                        # visitedStates[nextState] = cummulativeCost

        util.raiseNotDefined()

